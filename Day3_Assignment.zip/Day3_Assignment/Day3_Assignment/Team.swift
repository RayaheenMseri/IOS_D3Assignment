//
//  Team.swift
//  Day3_Assignment
//
//  Created by Taibah Valley Academy on 05/09/1446 AH.
//
import SwiftUI

enum TeamType: String {
    case National
    case Club
    case Academy 
}

class Team: Identifiable, ObservableObject {
    var id: UUID = UUID()
    var name: String
    var type: TeamType
    @Published var players: [Player] = []
    
    init(name: String, type: TeamType, players: [Player]) {
        self.name = name
        self.type = type
        self.players = players
    }
}
