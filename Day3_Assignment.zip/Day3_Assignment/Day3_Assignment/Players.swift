//
//  Players.swift
//  Day3_Assignment
//
//  Created by Taibah Valley Academy on 05/09/1446 AH.
//
import SwiftUI

struct Player: Identifiable {
    var id: UUID = UUID()
    var name: String
    var age: Int
    var position: String
}
