//
//  ViewModel.swift
//  Day3_Assignment
//
//  Created by Taibah Valley Academy on 05/09/1446 AH.
//
import SwiftUI

class teamViewModel: ObservableObject {
    @Published var teams: [Team] = [
        Team(name: "Al Hilal", type: .National, players: [Player(name: "Ahmed", age: 24, position: "GoalKeeper"),Player(name: "Ali", age: 27, position: "Defender"),]),
        Team(name: "Al Nassr", type: .Club, players: [Player(name: "Yaser", age: 30, position: "Forward"),Player(name: "Khalid", age: 28, position: "Defender"),]),
        Team(name: "Al Ittihad", type: .Academy, players: [Player(name: "Sami", age: 16, position: "GoalKeeper"),Player(name: "Majed", age: 17, position: "Midfielder"),])
    ]
    
    func addTeam(team: Team) {
        teams.append(team)
    }
    
    func addPlayer(to teamName: String, player: Player) {
        if let team = teams.first(where: { $0.name == teamName }) {
            team.players.append(player)
        }
    }
}

