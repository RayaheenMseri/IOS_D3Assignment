//
//  ContentView.swift
//  Day3_Assignment
//
//  Created by Taibah Valley Academy on 05/09/1446 AH.
//

import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = teamViewModel()
    
    var body: some View {
        NavigationStack {
            //list of teams
            List(viewModel.teams) { team in
                Section(header: Text("\(team.name) - \(team.type)")) {
                    HStack {
                        Text("Name")
                            .font(.headline)
                            .frame(width: 100, alignment: .center)
                        Spacer()
                        Text("Age")
                            .font(.headline)
                            .frame(width: 50, alignment: .center)
                        Spacer()
                        Text("Position")
                            .font(.headline)
                            .frame(width: 100, alignment: .center)
                    }
                    .padding(.bottom, 5)
                    // list of player
                    ForEach(team.players) { player in
                        HStack {
                            Text(player.name).frame(width: 100, alignment: .center)
                            Spacer()
                            Text("\(player.age)").frame(width: 100, alignment: .center)
                            Spacer()
                            Text(player.position).frame(width: 100, alignment: .center)
                        }
                    }
                }
            }
            .navigationTitle("Teams")
            //add team
            
            Button("Add Al Ahly Team") {
                viewModel.addTeam(team: Team(name: "Al Ahly", type: .National, players: [Player(name: "Omar", age: 26, position: "Forward")]))
            }
            .padding()
            .background(Color.black)
            .foregroundColor(.white)
            .cornerRadius(10)
        }
    }
}
#Preview {
    ContentView()
}
