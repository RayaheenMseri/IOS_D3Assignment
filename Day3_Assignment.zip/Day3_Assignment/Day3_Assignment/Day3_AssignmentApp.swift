//
//  Day3_AssignmentApp.swift
//  Day3_Assignment
//
//  Created by Taibah Valley Academy on 05/09/1446 AH.
//

import SwiftUI

@main
struct Day3_AssignmentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
